import React from 'react';

interface DaySelectorProps {
  selectedDay: number;
  daysInMonth: number;
  availableDays: number[];
  onDayChange: (day: number) => void;
}

const DaySelector: React.FC<DaySelectorProps> = ({ 
  selectedDay, 
  daysInMonth, 
  availableDays, 
  onDayChange 
}) => {
  // Get current month and year
  const currentDate = new Date();
  const monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];
  const currentMonth = monthNames[currentDate.getMonth()];
  const currentYear = currentDate.getFullYear();

  return (
    <div className="mb-8">
      <h3 className="text-lg font-medium text-gray-700 mb-3">{currentMonth} {currentYear}</h3>
      <div className="grid grid-cols-7 gap-2">
        {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => (
          <button
            key={day}
            onClick={() => onDayChange(day)}
            className={`
              py-2 px-3 rounded-md text-sm font-medium transition-colors flex items-center justify-center
              ${selectedDay === day 
                ? 'bg-[#F93657] text-white' 
                : availableDays.includes(day)
                  ? 'bg-red-100 text-[#F93657] hover:bg-red-200' 
                  : 'bg-gray-100 text-gray-400 cursor-not-allowed'
              }
            `}
            disabled={!availableDays.includes(day)}
          >
            {day}
          </button>
        ))}
      </div>
    </div>
  );
};

export default DaySelector;