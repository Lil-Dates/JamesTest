import React from 'react';
import { DateCard as DateCardType } from '../types';
import { Calendar, MapPin } from 'lucide-react';

interface DateCardProps {
  dateCard: DateCardType;
}

const DateCard: React.FC<DateCardProps> = ({ dateCard }) => {
  // Default image if none is provided
  const defaultImage = "https://images.unsplash.com/photo-1522264437900-69a3caa0f8eb?q=80&w=1000";
  
  // Get current date for display
  const currentDate = new Date();
  const currentMonth = new Intl.DateTimeFormat('en-US', { month: 'long' }).format(currentDate);
  const currentYear = currentDate.getFullYear();
  
  // Use the first available day from the date card for display
  const selectedDay = dateCard.availableDays[0] || currentDate.getDate();
  const formattedDate = `${selectedDay} ${currentMonth} ${currentYear}`;
  
  // Format price for display
  const priceDisplay = dateCard.price;
  
  // Format distance for display
  const distanceMatch = dateCard.distanceFromTube.match(/([<>])?(\d+(?:\.\d+)?)km/);
  const distance = distanceMatch ? distanceMatch[2] : "1";
  const prefix = distanceMatch && distanceMatch[1] === '<' ? 'less than ' : '';
  
  // Extract tube station
  const stationMatch = dateCard.distanceFromTube.match(/from\s+(.+)$/);
  const station = stationMatch ? stationMatch[1] : "station";
  
  // Default booking URL if none is provided
  const bookingUrl = dateCard.bookingUrl || "#";
  
  return (
    <div className="bg-white rounded-[24px] overflow-hidden max-w-md mx-auto" 
         style={{
           boxShadow: '0px 8px 28px -6px rgba(24, 39, 75, 0.05), 0px 18px 88px -4px rgba(24, 39, 75, 0.14)'
         }}>
      {/* Image section */}
      <div className="w-full h-56 overflow-hidden">
        <img 
          src={dateCard.imageUrl || defaultImage} 
          alt={dateCard.activity}
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="p-6">
        {/* Title = Inter Bold */}
        <h2 className="text-2xl mb-1" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 700 }}>{dateCard.activity}</h2>
        
        {/* Location = Inter Semibold */}
        <p className="text-[#F93657] text-lg mb-4" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600 }}>{dateCard.location}</p>
        
        {/* Description = Inter Regular */}
        <p className="text-gray-700 mb-8" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 400 }}>{dateCard.description}</p>
        
        {/* Date and Price */}
        <div className="flex items-center justify-between text-gray-500 mb-6">
          <div className="flex items-center">
            <Calendar className="h-5 w-5 mr-2 text-gray-400" />
            {/* Date = Inter Medium */}
            <span style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}>{formattedDate}</span>
          </div>
          <div>
            {/* Price = Inter Medium */}
            <span className="text-gray-500" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}>{priceDisplay}</span>
          </div>
        </div>
        
        {/* Tube Lines */}
        <div className="flex flex-wrap gap-2 mb-6">
          {dateCard.tubeLines.map((line, index) => (
            <div 
              key={index} 
              className="flex items-center"
            >
              <div className="h-6 w-6 rounded-full bg-black mr-1 flex items-center justify-center">
                <div className={`h-4 w-4 rounded-full ${getTubeLineColor(line)}`}></div>
              </div>
            </div>
          ))}
          <div className="flex items-center text-gray-700">
            {/* Distance = Inter Bold */}
            <span style={{ fontFamily: "'Inter', sans-serif", fontWeight: 700 }}>{prefix}{distance}km</span> 
            <span className="mx-1" style={{ fontFamily: "'Inter', sans-serif", fontWeight: 400 }}>from</span> 
            <span style={{ fontFamily: "'Inter', sans-serif", fontWeight: 700 }}>{station}</span>
          </div>
        </div>
        
        {/* Book Now Button - Now links to external URL and opens in new tab */}
        <a 
          href={bookingUrl} 
          target="_blank" 
          rel="noopener noreferrer" 
          className="block w-full bg-[#F93657] hover:bg-[#e02e4d] text-white py-4 px-6 rounded-full transition-colors text-center"
          style={{ fontFamily: "'Inter', sans-serif", fontWeight: 500 }}
        >
          Book now
        </a>
      </div>
    </div>
  );
};

// Helper function to get tube line colors
function getTubeLineColor(line: string): string {
  const lineColors: Record<string, string> = {
    'Bakerloo': 'bg-[#B36305]',
    'Central': 'bg-[#E32017]',
    'Circle': 'bg-[#FFD300]',
    'District': 'bg-[#00782A]',
    'Hammersmith & City': 'bg-[#F3A9BB]',
    'Jubilee': 'bg-[#A0A5A9]',
    'Metropolitan': 'bg-[#9B0056]',
    'Northern': 'bg-black',
    'Piccadilly': 'bg-[#003688]',
    'Victoria': 'bg-[#0098D4]',
    'Waterloo & City': 'bg-[#95CDBA]',
    'DLR': 'bg-[#00A4A7]',
    'Overground': 'bg-[#EE7C0E]',
    'Elizabeth': 'bg-[#6950A1]',
    'Tram': 'bg-[#84B817]'
  };
  
  return lineColors[line] || 'bg-gray-500';
}

export default DateCard;