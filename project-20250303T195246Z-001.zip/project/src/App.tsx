import React, { useState, useEffect, useMemo } from 'react';
import { Shuffle } from 'lucide-react';
import DateCard from './components/DateCard';
import DaySelector from './components/DaySelector';
import { DateCard as DateCardType } from './types';
import { supabase } from './lib/supabase';

function App() {
  const [selectedDay, setSelectedDay] = useState(1); // Default to 1st of the month
  const daysInMonth = 31; // Assuming March with 31 days
  const [dateCards, setDateCards] = useState<DateCardType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Fetch date cards from Supabase
  useEffect(() => {
    const fetchDateCards = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('date_cards')
          .select('*');
        
        if (error) {
          throw error;
        }
        
        if (data) {
          // Transform the data to match our DateCard type
          const transformedData: DateCardType[] = data.map(item => ({
            id: item.id,
            activity: item.activity,
            location: item.location,
            description: item.description,
            price: item.price,
            distanceFromTube: item.distance_from_tube,
            tubeLines: item.tube_lines,
            availableDays: item.available_days,
            imageUrl: item.image_url,
            bookingUrl: item.booking_url
          }));
          
          setDateCards(transformedData);
        }
      } catch (err) {
        console.error('Error fetching date cards:', err);
        setError('Failed to load date ideas. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchDateCards();
  }, []);
  
  // Get all days that have at least one date available
  const availableDays = useMemo(() => {
    const days = new Set<number>();
    dateCards.forEach(card => {
      card.availableDays.forEach(day => days.add(day));
    });
    return Array.from(days).sort((a, b) => a - b);
  }, [dateCards]);

  // Filter date cards available on the selected day
  const availableDateCards = useMemo(() => {
    return dateCards.filter(card => card.availableDays.includes(selectedDay));
  }, [dateCards, selectedDay]);

  const [currentDateCard, setCurrentDateCard] = useState<DateCardType | null>(null);

  // Get a random date card from the available ones, ensuring it's different from the current one
  const getRandomDateCard = () => {
    if (availableDateCards.length === 0) return null;
    
    // If there's only one date card available, return it
    if (availableDateCards.length === 1) return availableDateCards[0];
    
    // Filter out the current date card to ensure we get a different one
    const filteredCards = currentDateCard 
      ? availableDateCards.filter(card => card.id !== currentDateCard.id) 
      : availableDateCards;
    
    // If somehow all cards were filtered out (shouldn't happen with our logic), return from the original list
    if (filteredCards.length === 0) return availableDateCards[0];
    
    // Get a random card from the filtered list
    const randomIndex = Math.floor(Math.random() * filteredCards.length);
    return filteredCards[randomIndex];
  };

  // Initialize with a random date card when available cards change
  useEffect(() => {
    setCurrentDateCard(getRandomDateCard());
  }, [availableDateCards]);

  // Handle day change
  const handleDayChange = (day: number) => {
    setSelectedDay(day);
  };

  // Handle shuffle
  const handleShuffle = () => {
    setCurrentDateCard(getRandomDateCard());
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-red-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-5xl logo-font text-[#F93657] mb-2">lil dates</h1>
          <p className="text-xl subtitle-font text-gray-800">doing the hard bit for you</p>
        </header>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#F93657]"></div>
          </div>
        ) : error ? (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        ) : (
          <div className="grid md:grid-cols-[1fr_2fr] gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <DaySelector 
                selectedDay={selectedDay}
                daysInMonth={daysInMonth}
                availableDays={availableDays}
                onDayChange={handleDayChange}
              />
              
              <button
                onClick={handleShuffle}
                className="w-full flex items-center justify-center gap-2 bg-[#F93657] hover:bg-[#e02e4d] text-white font-medium py-3 px-4 rounded-md transition-colors mt-4"
                disabled={availableDateCards.length <= 1}
              >
                <Shuffle className="h-5 w-5" />
                Shuffle Date
              </button>
            </div>
            
            <div>
              {currentDateCard ? (
                <DateCard dateCard={currentDateCard} />
              ) : (
                <div className="bg-white rounded-lg shadow-md p-8 text-center">
                  <p className="text-gray-600">No date ideas available for this day. Try selecting another day.</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;