import { DateCard } from '../types';

// Sample date cards data
export const dateCards: DateCard[] = [
  {
    id: '1',
    activity: 'Greenhouse cocktails & hidden garden',
    location: '@The Barbican Conservatory',
    description: 'Get lost in the Barbican Conservatory, a hidden jungle in the city. Then, sip botanical cocktails at Nightjar and toast to your wild adventure!',
    price: '£££',
    distanceFromTube: '>1km from Barbican',
    tubeLines: ['Metropolitan', 'Hammersmith & City', 'Circle'],
    availableDays: [1, 2, 3, 4, 5, 6, 7]
  },
  {
    id: '2',
    activity: 'Vintage shopping & artisan coffee',
    location: '@Brick Lane',
    description: 'Hunt for treasures in Brick Lane\'s vintage markets, then recharge with specialty coffee at Allpress Espresso while discussing your unique finds.',
    price: '££',
    distanceFromTube: '<0.5km from Shoreditch High Street',
    tubeLines: ['Overground'],
    availableDays: [6, 7, 13, 14, 20, 21, 27, 28]
  },
  {
    id: '3',
    activity: 'Riverside walk & gourmet picnic',
    location: '@Southbank',
    description: 'Stroll along the Thames from London Bridge to Westminster, stopping to pick up artisanal treats from Borough Market for a scenic picnic.',
    price: '££',
    distanceFromTube: '<0.2km from Waterloo',
    tubeLines: ['Jubilee', 'Northern', 'Bakerloo'],
    availableDays: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  },
  {
    id: '4',
    activity: 'Immersive art & craft beer tasting',
    location: '@Bermondsey Beer Mile',
    description: 'Experience the latest immersive exhibition at Tate Modern, then sample craft beers along the Bermondsey Beer Mile for a perfect blend of culture and relaxation.',
    price: '£££',
    distanceFromTube: '<0.8km from London Bridge',
    tubeLines: ['Jubilee', 'Northern'],
    availableDays: [5, 6, 7, 12, 13, 14, 19, 20, 21, 26, 27, 28]
  },
  {
    id: '5',
    activity: 'Rooftop cinema & street food',
    location: '@Roof East, Stratford',
    description: 'Watch a cult classic film under the stars at Roof East\'s rooftop cinema, paired with delicious street food and panoramic views of the London skyline.',
    price: '££',
    distanceFromTube: '<0.1km from Stratford',
    tubeLines: ['Central', 'Jubilee', 'DLR', 'Overground'],
    availableDays: [12, 13, 14, 19, 20, 21, 26, 27, 28]
  },
  {
    id: '6',
    activity: 'Hidden bookshop & literary cocktails',
    location: '@Daunt Books, Marylebone',
    description: 'Lose yourself in the oak galleries of Daunt Books, then discuss your literary discoveries over themed cocktails at Nightjar, where drinks are inspired by different eras of literature.',
    price: '££',
    distanceFromTube: '<0.3km from Baker Street',
    tubeLines: ['Bakerloo', 'Circle', 'Hammersmith & City', 'Jubilee', 'Metropolitan'],
    availableDays: [1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 15, 16, 17, 18, 19]
  },
  {
    id: '7',
    activity: 'Urban kayaking & waterside brunch',
    location: '@Regent\'s Canal',
    description: 'Paddle through London\'s hidden waterways on a kayaking adventure along Regent\'s Canal, followed by a well-deserved brunch at a canalside café in Little Venice.',
    price: '£££',
    distanceFromTube: '<0.5km from Paddington',
    tubeLines: ['Bakerloo', 'Circle', 'District', 'Hammersmith & City'],
    availableDays: [6, 7, 13, 14, 20, 21, 27, 28]
  }
];