export interface DateCard {
  id: string;
  activity: string;
  location: string;
  description: string;
  price: string;
  distanceFromTube: string;
  tubeLines: string[];
  availableDays: number[]; // Days of the month when this date is available
  imageUrl?: string | null; // URL to an image representing the date
  bookingUrl?: string | null; // URL for booking this date
}

export * from './supabase';