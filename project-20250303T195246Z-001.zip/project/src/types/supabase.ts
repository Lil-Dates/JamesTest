export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      date_cards: {
        Row: {
          id: string
          activity: string
          location: string
          description: string
          price: string
          distance_from_tube: string
          tube_lines: string[]
          available_days: number[]
          created_at: string
          image_url: string | null
          booking_url: string | null
        }
        Insert: {
          id?: string
          activity: string
          location: string
          description: string
          price: string
          distance_from_tube: string
          tube_lines: string[]
          available_days: number[]
          created_at?: string
          image_url?: string | null
          booking_url?: string | null
        }
        Update: {
          id?: string
          activity?: string
          location?: string
          description?: string
          price?: string
          distance_from_tube?: string
          tube_lines?: string[]
          available_days?: number[]
          created_at?: string
          image_url?: string | null
          booking_url?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}