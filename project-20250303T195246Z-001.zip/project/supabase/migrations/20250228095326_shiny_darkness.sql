/*
  # Create date_cards table

  1. New Tables
    - `date_cards`
      - `id` (uuid, primary key)
      - `activity` (text)
      - `location` (text)
      - `description` (text)
      - `price` (text)
      - `distance_from_tube` (text)
      - `tube_lines` (text array)
      - `available_days` (integer array)
      - `created_at` (timestamp with time zone)
  2. Security
    - Enable RLS on `date_cards` table
    - Add policy for public read access
    - Add policy for authenticated users to manage their own data
*/

CREATE TABLE IF NOT EXISTS date_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  activity text NOT NULL,
  location text NOT NULL,
  description text NOT NULL,
  price text NOT NULL,
  distance_from_tube text NOT NULL,
  tube_lines text[] NOT NULL,
  available_days integer[] NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE date_cards ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Allow public read access"
  ON date_cards
  FOR SELECT
  TO public
  USING (true);

-- Create policy for authenticated users to insert their own data
CREATE POLICY "Allow authenticated users to insert their own data"
  ON date_cards
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create policy for authenticated users to update their own data
CREATE POLICY "Allow authenticated users to update their own data"
  ON date_cards
  FOR UPDATE
  TO authenticated
  USING (true);

-- Create policy for authenticated users to delete their own data
CREATE POLICY "Allow authenticated users to delete their own data"
  ON date_cards
  FOR DELETE
  TO authenticated
  USING (true);

-- Insert sample data
INSERT INTO date_cards (activity, location, description, price, distance_from_tube, tube_lines, available_days)
VALUES
  (
    'Greenhouse cocktails & hidden garden',
    '@The Barbican Conservatory',
    'Get lost in the Barbican Conservatory, a hidden jungle in the city. Then, sip botanical cocktails at Nightjar and toast to your wild adventure!',
    '£££',
    '>1km from Barbican',
    ARRAY['Metropolitan', 'Hammersmith & City', 'Circle'],
    ARRAY[1, 2, 3, 4, 5, 6, 7]
  ),
  (
    'Vintage shopping & artisan coffee',
    '@Brick Lane',
    'Hunt for treasures in Brick Lane''s vintage markets, then recharge with specialty coffee at Allpress Espresso while discussing your unique finds.',
    '££',
    '<0.5km from Shoreditch High Street',
    ARRAY['Overground'],
    ARRAY[6, 7, 13, 14, 20, 21, 27, 28]
  ),
  (
    'Riverside walk & gourmet picnic',
    '@Southbank',
    'Stroll along the Thames from London Bridge to Westminster, stopping to pick up artisanal treats from Borough Market for a scenic picnic.',
    '££',
    '<0.2km from Waterloo',
    ARRAY['Jubilee', 'Northern', 'Bakerloo'],
    ARRAY[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  ),
  (
    'Immersive art & craft beer tasting',
    '@Bermondsey Beer Mile',
    'Experience the latest immersive exhibition at Tate Modern, then sample craft beers along the Bermondsey Beer Mile for a perfect blend of culture and relaxation.',
    '£££',
    '<0.8km from London Bridge',
    ARRAY['Jubilee', 'Northern'],
    ARRAY[5, 6, 7, 12, 13, 14, 19, 20, 21, 26, 27, 28]
  ),
  (
    'Rooftop cinema & street food',
    '@Roof East, Stratford',
    'Watch a cult classic film under the stars at Roof East''s rooftop cinema, paired with delicious street food and panoramic views of the London skyline.',
    '££',
    '<0.1km from Stratford',
    ARRAY['Central', 'Jubilee', 'DLR', 'Overground'],
    ARRAY[12, 13, 14, 19, 20, 21, 26, 27, 28]
  ),
  (
    'Hidden bookshop & literary cocktails',
    '@Daunt Books, Marylebone',
    'Lose yourself in the oak galleries of Daunt Books, then discuss your literary discoveries over themed cocktails at Nightjar, where drinks are inspired by different eras of literature.',
    '££',
    '<0.3km from Baker Street',
    ARRAY['Bakerloo', 'Circle', 'Hammersmith & City', 'Jubilee', 'Metropolitan'],
    ARRAY[1, 2, 3, 4, 5, 8, 9, 10, 11, 12, 15, 16, 17, 18, 19]
  ),
  (
    'Urban kayaking & waterside brunch',
    '@Regent''s Canal',
    'Paddle through London''s hidden waterways on a kayaking adventure along Regent''s Canal, followed by a well-deserved brunch at a canalside café in Little Venice.',
    '£££',
    '<0.5km from Paddington',
    ARRAY['Bakerloo', 'Circle', 'District', 'Hammersmith & City'],
    ARRAY[6, 7, 13, 14, 20, 21, 27, 28]
  );