/*
  # Add image_url field to date_cards table

  1. Changes
    - Add `image_url` column to `date_cards` table
    - This column will store URLs to images representing each date activity
  
  2. Notes
    - The column is nullable to maintain compatibility with existing records
    - We'll update existing records with sample image URLs
*/

-- Add image_url column to date_cards table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'date_cards' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE date_cards ADD COLUMN image_url text;
  END IF;
END $$;

-- Update existing records with sample image URLs
UPDATE date_cards SET image_url = 'https://images.unsplash.com/photo-1518005068251-37900150dfca?q=80&w=1000' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Greenhouse cocktails & hidden garden' LIMIT 1);
UPDATE date_cards SET image_url = 'https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?q=80&w=1000' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Vintage shopping & artisan coffee' LIMIT 1);
UPDATE date_cards SET image_url = 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?q=80&w=1000' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Riverside walk & gourmet picnic' LIMIT 1);
UPDATE date_cards SET image_url = 'https://images.unsplash.com/photo-1577583113753-ca7e95d1bdc6?q=80&w=1000' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Immersive art & craft beer tasting' LIMIT 1);
UPDATE date_cards SET image_url = 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=1000' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Rooftop cinema & street food' LIMIT 1);
UPDATE date_cards SET image_url = 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?q=80&w=1000' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Hidden bookshop & literary cocktails' LIMIT 1);
UPDATE date_cards SET image_url = 'https://images.unsplash.com/photo-1472745942893-4b9f730c7668?q=80&w=1000' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Urban kayaking & waterside brunch' LIMIT 1);