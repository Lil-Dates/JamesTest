/*
  # Add booking URL to date cards

  1. Changes
    - Add `booking_url` column to `date_cards` table
    - Update existing records with sample booking URLs
  
  2. Purpose
    - Allow "Book Now" button to link to external booking websites
    - Enable opening links in new tabs
*/

-- Add booking_url column to date_cards table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'date_cards' AND column_name = 'booking_url'
  ) THEN
    ALTER TABLE date_cards ADD COLUMN booking_url text;
  END IF;
END $$;

-- Update existing records with sample booking URLs
UPDATE date_cards SET booking_url = 'https://www.barbican.org.uk/whats-on/series/conservatory' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Greenhouse cocktails & hidden garden' LIMIT 1);
UPDATE date_cards SET booking_url = 'https://www.visitbricklane.org/markets' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Vintage shopping & artisan coffee' LIMIT 1);
UPDATE date_cards SET booking_url = 'https://www.southbanklondon.com/' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Riverside walk & gourmet picnic' LIMIT 1);
UPDATE date_cards SET booking_url = 'https://www.tate.org.uk/visit/tate-modern' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Immersive art & craft beer tasting' LIMIT 1);
UPDATE date_cards SET booking_url = 'https://www.roofeast.com/' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Rooftop cinema & street food' LIMIT 1);
UPDATE date_cards SET booking_url = 'https://dauntbooks.co.uk/' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Hidden bookshop & literary cocktails' LIMIT 1);
UPDATE date_cards SET booking_url = 'https://www.londonkayaktours.co.uk/' WHERE id = (SELECT id FROM date_cards WHERE activity = 'Urban kayaking & waterside brunch' LIMIT 1);